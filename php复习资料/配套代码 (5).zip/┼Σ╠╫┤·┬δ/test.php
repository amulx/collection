<?php



	$arr = array(20, 18, 33, 17, 44, 15, 22, 13, 25, 34, 11, 18, 66);



	function qsort($arr) {
		if(!is_array($arr) || empty($arr))
			return array();

		//获取数组的长度
		$len = count($arr);

		//如果数组中只有一个元素, 直接返回这个数组
		if($len <= 1)
			return $arr;

		$key[0] = $arr[0];

		$left = array();
		$right = array();

		for($i = 1; $i<$len; $i++) {
			if($arr[$i] <= $key[0]) {
				$left[]=$arr[$i];
			}else{
				$right[] = $arr[$i];
			}
		}

	
		$left=qsort($left);
		$right=qsort($right);


		return array_merge($left, $key, $right);
	}



	print_r($arr);
	echo '<br>';


	print_r(qsort($arr)); 
