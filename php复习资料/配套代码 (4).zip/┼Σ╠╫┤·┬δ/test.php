<?php
/*
 *   使用for遍历数组
 *
 *
 *   保证数组： 一定要是下标连续的索引数组
 *
 * 优点：
 *
 *   效率很高， 就是数组访问方式， 只不过通过循环去取值
 *
 *   count(数组) 获取数组的长度, 是数组的实际元素的个数
 *
 *不足：
 	1. 数组下标不一定是连续的

	*	2. 关联数组for 不能遍历出值
	*
	*

	foreach() 语法


	1. 
	foreach(数组 as 自定义变量) {
	
	} 

	一、 数组有多少个元素， foreach就循环多少次
		二、foreach会将数组中的元素 在每次循环中， 依次将元素的值给自定义的变量， 在每次循环中用到这个变量，即用到了当前的数组中的元素


	2. 
	foreach(数组 as 下标变量 => 值变量) {
		
	} 
 *
 */

/*	$arr = array("one"=>"aa", "bb", "three"=>"cc", "dd", 9=>"ee", "ff", "four"=>"ggg", "hh", "xxx", "yyy", "zz");



	foreach($arr as $kk => $vv) {
		echo "{$kk} =============> {$vv} <br>";
	}

 */

	
/*

	$group = [
			"name"=>"第三组",
			"price"=>888,
		 	["name"=>"zs", "age"=>20, "sex"=>"男", "email"=>"aaa@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ww", "age"=>22, "sex"=>"男", "email"=>"cccc@bbb.com"]
	];



	echo '<table border="1" width="800" align="center">';
	echo '<caption><h1>数组转为表格<h1></caption>';


	foreach($group as $k=>$row) {

		echo '<tr>';

		if(is_array($row)) {
			foreach($row as $col) {
				echo '<td>'.$col.'</td>';
			}
		} else {
			echo '<td colspan="4">'.$k.':'.$row.'</td>';
		}

		echo '</tr>';
	
	}

	echo '</table>';

 */


/*
 *
 *  list() 函数 但这个函数和其它函数用法不同
 *
 *
 *  作用： 将数组中的元素转为变量使用
 *
 *   1. 等号左边使用list()函数， 等号右边只能是一个数组
 *
 *   2. 数组中有几个元素， 在list()中就用几个参数，而且参数必数是变量(新声明的自定义变量)， 不能是值
 *
 *   3. 只能将索引数组(下标是连续)， 转为变量, 是按下标0开始找的
 *
 *   4. 可以在list()参数中通过，空项选择性的接收数组中的元素
 *
 */


/*
	list($a, , $c) = array("妹子", "峰哥", "第三者");


	echo $a."<br>";
//	echo $b."<br>";
	echo $c."<br>";

 

	
	$str="峰哥_好帅";

	
list($name,$pro) = explode("_", $str);

echo $name.'<br>';
echo $pro.'<br>';

 */
/*
 *   each() 只是一个函数, 参数就是一个数组作为参数, 返回的值，也是一个数组
 *
 *   1. 返回的值是一个数组， 数组固定有4个元素， 而且下标也是固定的   ( 1(值)    value(值) ) (   0(下标)    key(下标) )
 *   2. each() 只处理当前的元素将当前的元素(默认当前元素是第一个元素，指针指向第一个)转为数组信息, 处理完后， 指针向下一个元素移动
 *
 *   3. 如果指定已经在结束位置了， 如果在使用each()获取元素, 返回false
 */
/*	$arr = ["one"=>"妹子", "峰哥", "第三者"];


	echo '<pre>';
	
	
	$one = each($arr);
	print_r($one);


	$one = each($arr);
	print_r($one);




	$one = each($arr);
	print_r($one);



	$one = each($arr);
	var_dump($one);

	 echo '</pre>';

 */
/*
	$arr = ["one"=>"妹子", "峰哥", "第三者", "four", "five"];

	while(list(, $val) = each($arr)) {
		//echo "{$tmp['key']} => {$tmp['value']} <br>";
		//echo "{$tmp[0]} => {$tmp[1]} <br>";
		echo "{$val} <br>";
	}


	reset($arr);

	while(list(, $val) = each($arr)) {
		//echo "{$tmp['key']} => {$tmp['value']} <br>";
		//echo "{$tmp[0]} => {$tmp[1]} <br>";
		echo "{$val} <br>";
	}


	reset($arr);
	while(list(, $val) = each($arr)) {
		//echo "{$tmp['key']} => {$tmp['value']} <br>";
		//echo "{$tmp[0]} => {$tmp[1]} <br>";
		echo "{$val} <br>";
	}


 */






	$group = [
			"name"=>"第三组",
			"price"=>888,
		 	["name"=>"zs", "age"=>20, "sex"=>"男", "email"=>"aaa@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ls", "age"=>21, "sex"=>"女", "email"=>"bbb@bbb.com"], 
			["name"=>"ww", "age"=>22, "sex"=>"男", "email"=>"cccc@bbb.com"]
	];



	echo '<table border="1" width="800" align="center">';
	echo '<caption><h1>数组转为表格<h1></caption>';

	//foreach($group as $k => $row) {
	while(list($k, $row) = each($group)) {

		echo '<tr>';

		if(is_array($row)) {
			//foreach($row as $col) {
			while(list(, $col) =each($row)) {
				echo '<td>'.$col.'</td>';
			}
		} else {
			echo '<td colspan="4">'.$k.':'.$row.'</td>';
		}

		echo '</tr>';
	
	}

	echo '</table>';



















































